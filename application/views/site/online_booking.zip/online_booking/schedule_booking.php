<!-- banner -->
<section class="inner_page uk-clearfix">
            <div class="uk_container ">
            <form action="<?php echo base_url(); ?>index.php/welcome/schedule_booking" method="post">

                <div class="uk-card uk-card-default uk-card-body uk-padding-remove-top">
                    <div class="title">
                    
                    <div uk-grid>
                            
                        <div class="uk-width-expand@m">
                            <h3> Bill - <?php echo $last_id;?> </h3>

                        </div>
                        <div class="uk-width-1-6@m"  style="text-align: right;     padding-top: 7px;">
                            <label class="uk-form-label" for="form-stacked-text">Bill Date</label>
                        </div>
                        <div class="uk-width-1-5@m">
                            <div class=" form_group">
    
                                    
                              
                                <div class="uk-form-controls">
                                <?php $today=date("Y-m-d"); ?>
                                    
                                        <input class="uk-input" id="form-stacked-text" type="date" name="datee" id="bill_date" max="<?php echo $today ?>" value="<?php echo $today ?>">
    
                               
                                </div>
                            </div>

                        </div>
                    </div>
                    </div>
                 
                    <div class="form_wraper">
                        
                    <?php
                    $this->db->select('diety_pooja.*,diety.name as diety,pooja.name as pooja,pooja.name_mal as pooja_mal,pooja.rate as pooja_rt,pooja.code');
                    $this->db->from('diety_pooja');
                    $this->db->join('pooja','pooja.id = diety_pooja.pooja_id');
                    $this->db->join('diety','diety.id = diety_pooja.temple_id');
                    $this->db->where('diety_pooja.id', $id);
                    $this->db->order_by("pooja.name", "asc");
                    $query = $this->db->get()->row_array();
                    ?>


                    <ul class="uk_form_schedule">
                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Diety</label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <div class="">
                                        <input class="uk-input" id="form-stacked-text" name="diety_name" type="text" placeholder="Diety" readonly value="<?= $query['diety'];?>">
                                        <input id="diety" name="diety_id" type="hidden" value="<?= $query['temple_id'];?>">
                                    </div>
    
                                </div>
                            </div>

                        </li>
                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                      Name</label>
                                <div class="uk-form-controls">
                                 
                                    
                                        <input class="uk-input" id="form-stacked-text" name="name" type="text" placeholder="Name">
    
                               
                                </div>
                            </div>

                        </li>
                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Star</label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <div class="wrap_select_dropdown">
                                            
                                        <select class="drop_category uk-input  drop_select hide star11" name="star_id" onchange="chage_star()" style="width: 100%;">
                                            <option value="">Select Star</option>
                                            <?php foreach($star_list as $val){ ?>  
                                                <option data-name="<?= $val['name_eng']; ?>" value="<?= $val['id']; ?>"><?= $val['name_eng']; ?></option>
                                            <?php } ?>
                                        
                                        </select>
                                    </div>
    
                               
                                </div>
                            </div>

                        </li>

                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Pooja</label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <div class="wrap_select_dropdown">
                                        <input class="uk-input" id="form-stacked-text" name="pooja_name" type="text" placeholder="Pooja" readonly value="<?= $query['pooja'];?>">
                                        <input id="pooja" name="pooja_id" type="hidden" value="<?= $query['pooja_id'];?>">  
                                    </div>
                               
                                </div>
                            </div>

                        </li>

                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Quantity</label>
                                <div class="uk-form-controls">
                                 
                                    
                                        <input class="uk-input" id="qlt" type="number" min="1" name="qlt" onchange="change_rate()" onkeyup="change_rate()" value="1">
    
                               
                                </div>
                            </div>

                        </li>

                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Rate</label>
                                <div class="uk-form-controls">
                                 
                                    
                                        <input class="uk-input" id="rate" type="text" name="rate" placeholder=" Rate" value="<?= $query['pooja_rt'];?>" readonly>
    
                               
                                </div>
                            </div>

                        </li>

                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Amount </label>
                                <div class="uk-form-controls">
                                 
                                    
                                        <input class="uk-input" id="amt" type="text" name="amt" placeholder=" Amount" value="<?= $query['pooja_rt'];?>" readonly>
    
                               
                                </div>
                            </div>

                        </li>

                        <li> 
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">
                                    Time</label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <select name="time" id="time" class="drop_category uk-input drop_select hide" required style="width: 100%;">
                                        <option value="M" selected="selected">M</option>
                                        <option value="E">E</option>
                                    </select>
    
                               
                                </div>
                            </div>

                        </li>

                    

                    </ul>

                </div>

               
                <div class="form_wraper">

                    <ul class="uk_form_schedule">
                        <li>   
                            <div class=" form_group">
        
                                        
                            <label class="uk-form-label" for="form-stacked-text">D/W/M/O</label>
                            <div class="uk-form-controls">
                             
                                
                                <div class="wrap_select_dropdown">
                                
                                    <select class="drop_category uk-input  drop_select hide "  name="dmyo" id="dmyo" onchange="optionalfield()" style="width: 100%;" required>
                                        <option value="0">Select </option>
                                        <option value="1">Daily </option>
                                        <option value="2">Weekly </option>
                                        <option value="3">Monthly </option>
                                        <option value="4">Other </option>
                                    </select>
                                </div>
                           
                          

                           
                            </div>
                        </div></li>

                        <li>
                            <div class=" form_group">

                                        
                                <label class="uk-form-label" for="form-stacked-text">From Date</label>
                                <div class="uk-form-controls">
                                
                                    
                                        <input class="uk-input" name="main_date" id="datefrom" type="date" min="<?php echo date('Y-m-d');?>" value="<?php echo date('Y-m-d');?>">

                            
                                </div>
                            </div>


                        </li>

                        <li class="weekday">
                            <div class=" form_group">

                                        
                                <label class="uk-form-label" for="form-stacked-text">Week Day</label>
                                <div class="uk-form-controls">
                                
                                    
                                    <select name="week" id="week" class="drop_category uk-input drop_select hide">
                                        <option value="">Select </option>
                                        <option value="Sunday">Sunday </option>
                                        <option value="Monday">Monday </option>
                                        <option value="Tuesday">Tuesday </option>
                                        <option value="Wednesday">Wednesday </option>
                                        <option value="Thursday">Thursday </option>
                                        <option value="Friday">Friday </option>
                                        <option value="Saturday">Saturday </option>
                                    </select>

                            
                                </div>
                            </div>

                        </li>

                        <li class="star">
                            <div class=" form_group">

                                        
                                <label class="uk-form-label" for="form-stacked-text">Star</label>
                                <div class="uk-form-controls">
                                
                                    
                                    <select name="star" id="month" class="drop_category uk-input  drop_select hide star12" >
                                        <option value="">Select Star</option>
                                        <?php foreach($star_list as $val){ ?>  
                                            <option value="<?= $val['name_eng']; ?>"><?= $val['name_eng']." - ".$val['name_mal']; ?></option>
                                        <?php } ?>
                                    </select>

                            
                                </div>
                            </div>

                        </li>

                        <li class="other">
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">Other </label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <select name="other" id="other_id" class="drop_category uk-input  drop_select hide">
                                        <option value="0">Please Select</option>
                                        <?php foreach($other_list as $val){ ?>
                                        <option value="<?= $val['other_code']; ?>"><?= $val['other_detail']; ?></option>
                                        <?php } ?>
                                    </select>
    
                               
                                </div>
                            </div>

                        </li>
                        <li class="year">
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">Year</label>
                                <div class="uk-form-controls">
                                 
                                        <input type="number" name="date" class="uk-input" min="0" id="years" value="0" />
    
                               
                                </div>
                            </div>
                        </li>

                        <li class="month">
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">Month</label>
                                <div class="uk-form-controls">
                                 
                                        <input type="number" name="date" class="uk-input" min="0" id="months" value="0" />
    
                               
                                </div>
                            </div>
                        </li>

                        <li class="week">
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">Week</label>
                                <div class="uk-form-controls">
                                 
                                        <input type="number" name="date" class="uk-input" min="0" id="weeks" value="0" />
    
                               
                                </div>
                            </div>
                        </li>

                        <li class="day">
                            <div class=" form_group">

                                        
                                <label class="uk-form-label" for="form-stacked-text">Days</label>
                                <div class="uk-form-controls">
                                
                                        <input type="number" name="date" class="uk-input" min="0" id="days" value="0" />

                            
                                </div>
                            </div>
                        </li>

                        <li>
                            <div class=" form_group">
        
                                        
                                <label class="uk-form-label" for="form-stacked-text">Prasadam</label>
                                <div class="uk-form-controls">
                                 
                                    
                                    <select name="prasadam" id="prasadam" class="drop_category uk-input  drop_select hide" required>
                                        <option value="2">Please Select</option>
                                        <option value="1">Yes </option>
                                        <option value="0">No </option>
                                    </select>
    
                               
                                </div>
                            </div>

                        </li>

                        
                        <!-- <li class="amount">   <div class=" form_group">
        
                                        
                            <label class="uk-form-label" for="form-stacked-text">Postel Amount</label>
                            <div class="uk-form-controls">
                             
                                
                                <div class="wrap_select_dropdown">
                                
                                    <input type="text" name="parcel_amt" id="parsel_amt" class="uk-input" onkeyup="check_dmyo(),totalgross()" placeholder="Amount"  value="">
                                </div>
                           
                          

                           
                            </div>
                        </div></li> -->

                        </ul>

                        </div>

                     

                    <div class="uk-overflow-auto">
                    <table class="uk-table uk-table-hover uk-table-divider display" id="st" >
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>Star</th>
                                <th>Prasadam</th>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="mytbody"></tbody>
                    </table>
                </div>
                    
                <hr>


                <div >
                    <div class="uk-margin-medium-bottom uk-margin-small-top uk-text-right uk-grid-margin uk-first-column">

                        <div class=" form_group ">

                            
                            <button type="submit" class="btn_com">Add To Cart</button>
                        </div>
                    </div>


                </div>

                    </div>


                </div>
            </form>
            </div>

 


        </section>
     

        <footer>
            <div class="uk_container">
                        <a href=""> 2021 All rights reserved.</a>

            </div>
        </footer>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/datejs/1.0/date.min.js" integrity="sha512-/n/dTQBO8lHzqqgAQvy0ukBQ0qLmGzxKhn8xKrz4cn7XJkZzy+fAtzjnOQd5w55h4k1kUC+8oIe6WmrGUYwODA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    $('.star').hide();
    $('.other').hide();
    $('.weekday').hide();
    $('.year').hide();
    $('.month').hide();
    $('.week').hide();
    $('.day').hide();
    $('.pay_details').hide();
    $('.dateto').hide();

 
    $( "#prasadam" ).change(function() {
        prasadamfield();
        totalgross();
    });
    
    function chage_star(){
        var star11=$('.star11').val();
        $('.star12').val(star11).select();
    }
       
    function change_rate(){
        var rate=$('#rate').val();
        var qlt=$('#qlt').val();                                  
        var amt=qlt*rate;
        $('#amt').val(amt);
    }
    function remove_file_row(obj){
        $(obj).closest('tr').remove();
        totalgross();
        checkBal();
        return false;
    }
    function check_dmyo(){
        var dmyo=$('#dmyo').val();
        if(dmyo==1){
            dailysub();
        }
        else if (dmyo==2){
            weeklysub();
        }
        else if (dmyo==3){
            monthlysub();
        }
        else if(dmyo==4){
            othersub();
        }
    }
    function optionalfield(){
            var dmyo=$('#dmyo').val();  
            if(dmyo==1){
            $('.star').hide();
            $('.weekday').hide();
            $('.other').hide();
            $('.day').show();
            $('.month').hide();
            $('.week').hide();
            }
            else if(dmyo==2){
            $('.star').hide();
            $('.other').hide();
            $('.weekday').show();
            $('.week').show();
            $('.month').hide();
            $('.day').hide();
            }
            else if(dmyo==3){
            $('.star').show();
            $('.other').hide();
            $('.weekday').hide();
            $('.month').show();
            $('.day').hide();
            $('.week').hide();
            }
            else if(dmyo==4){
            $('.star').hide();
            $('.other').show();
            $('.weekday').hide();
            $('.day').hide();
            $('.week').hide();
            $('.month').show();
            }
        
        }
            
        function prasadamfield(){  
            var prasadam=$('#prasadam').val();
            if(prasadam==1){
                $('.amount').show();
            }
            else{
                $('.amount').hide();
            }
            check_dmyo();
        } 
        function totalcalc(){
            var i;
            var table = document.getElementById('dataTable1');
            var rowCount = table.rows.length;
            var tpoojacount = parseInt($('#st tr').length) - 1;
            //alert(tpoojacount);
            var tot=0;
            var pr_amt=($('#parsel_amt').val() != '') ?  $('#parsel_amt').val() :  0;
        
            for (i = 100; i < 1000; i++) {
                if (!isNaN(parseInt($('#amt_'+i).val()))){
                    tot += parseInt($('#amt_'+i).val());
                }
            }
            tot=tot+parseFloat(pr_amt);
            $('#total').html(tot);
            var grosstotal = tot * tpoojacount;
            $('#gtotal').html(grosstotal);
            $('#bill_amount').val(grosstotal);
            $('#amount_received').val(grosstotal);
        }
        function totalgross(){
            var i;
            var table = document.getElementById('dataTable1');
            var rowCount = table.rows.length;
            var billtype=$('#billtype:checked').val();
            console.log(billtype);
            var tpoojacount = parseInt($('#st tr').length) - 1;
            //alert(tpoojacount);
            var tot = parseInt($('#amt').val());
            var pr_amt=($('#parsel_amt').val() != '') ?  $('#parsel_amt').val() :  0;
            
            tot=tot+parseFloat(pr_amt);
            var pc = (tpoojacount == 0) ? 1 : tpoojacount;
            $('#total').html(tot);
            var grosstotal = tot * pc;
            console.log(pc);
            $('#gtotal').html(grosstotal);
            $('#bill_amount').val(grosstotal);
            $('#amount_received').val(grosstotal);
            if(billtype == 1){
                $('#amount_received').val(grosstotal);
                $('#balance').val(0);
            }
            else{
            $('#amount_received').val(0);
            $('#balance').val(0);
            }
            
        }
        function checkBal(){
            var bill_amt = $('#bill_amount').val();
            var rec_amt = $('#amount_received').val();
            var bal = bill_amt - rec_amt;
            $('#balance').val(bal);
        }
        function dailysub(){
            var datefrom=$('#datefrom').val();
            var days = parseInt($('#days').val());
            var week = parseInt($('#weeks').val());
            var month = parseInt($('#months').val());
            var year = parseInt($('#years').val());
        // var dateto=$('#dateto').val();
            var date = Date.parse(datefrom).add({ years: year, months: month, weeks:week, days:days-1 });
            var dateto =  date.toString('yyyy-MM-dd');
            if(datefrom==""){
                alert("Date field is required");
            }else if(dateto==""){
                alert("Date field is required");
            }
            $(".display").removeAttr('style');
            $(".buttons").removeAttr('style');
            $("#cdt").val(dateto);
            var url = '<?php echo base_url();?>index.php/welcome/getdatestar';
            var html="";
            var pr_amt=$('#parsel_amt').val();
            if($('#prasadam').val() == 1){
            var prasadam_status = 'Yes';
            }
            else if($('#prasadam').val() == 0){
            var prasadam_status = 'No';  
            pr_amt = 0;
            }
            
            var time = $('#time').val();
            var a="1";
            $.ajax({
                type: "POST",
                url: url,
                data: {'from': datefrom,'to': dateto},
                dataType: "json",
                success: function (data) {
                    $.each(data, function (i, obj)
                    {
                        html +='<tr><td>'+a+'</td>';
                        html +='<td>'+obj.date+'<input type="hidden" name="dates[]" value="'+obj.birth_date+'"></td>';
                        html +='<td>'+obj.name_eng+'</td>';
                        html +='<td>'+prasadam_status+'</td>';
                        html +='<td>'+time+'</td>';
                        html +='<td><i class="fa fa-trash" onclick="return remove_file_row(this)"></i></td></tr>';
                        a++;
                    });
                    $('#mytbody').html(html);
                    
                }
            });
            return true;
        }	
    function weeklysub(){

        var datefrom=$('#datefrom').val();
        //ar dateto=$('#dateto').val();
            var days = parseInt($('#days').val());
            var week = parseInt($('#weeks').val());
            var month = parseInt($('#months').val());
            var year = parseInt($('#years').val());
            var date = Date.parse(datefrom).add({ years: year, months: month, weeks:week, days:days });
            var dateto =  date.toString('yyyy-MM-dd');
        if(datefrom==""){
            alert("Date field is required");
        }else if(dateto==""){
            alert("Date field is required");
        }
        $(".display").removeAttr('style');
        $(".buttons").removeAttr('style');
        $("#cdt").val(dateto);
        var url = '<?php echo base_url();?>index.php/welcome/getweekstar';
        var html="";
        var pr_amt=$('#parsel_amt').val();
            if($('#prasadam').val() == 1){
            var prasadam_status = 'Yes';
            }
            else if($('#prasadam').val() == 0){
            var prasadam_status = 'No';  
            pr_amt = 0;
            }
            
            var time = $('#time').val();
        var a="1";
        var sel=$('#week option:selected').map(function(_, el) {
            var days=$(el).val();
            $.ajax({
                type: "POST",
                url: url,
                data: {'from': datefrom,'to': dateto,'day': days,'noofweeks':week},
                dataType: "json",
                success: function (data) {
                    $.each(data, function (i, obj)
                    {
                        html +='<tr><td>'+a+'</td>';
                        html +='<td>'+obj.date+'<input type="hidden" name="dates[]" value="'+obj.birth_date+'"></td>';
                        html +='<td>'+obj.name_eng+'</td>';
                        html +='<td>'+prasadam_status+'</td>';
                        html +='<td>'+time+'</td>';
                        html +='<td><i class="fa fa-trash" onclick="return remove_file_row(this)"></i></td></tr>';
                        a++;
                    });
                    $('#mytbody').html(html);
                    
                }
            });
        }).get();
        
    }
    function monthlysub(){
        var datefrom=$('#datefrom').val();
        var days = parseInt($('#days').val());
            var week = parseInt($('#weeks').val());
            var month = parseInt($('#months').val());
            var year = parseInt($('#years').val());
        // var dateto=$('#dateto').val();
            var date = Date.parse(datefrom).add({ years: year, months: month, weeks:week, days:days });
            var dateto =  date.toString('yyyy-MM-dd');
        if(datefrom==""){
            alert("Date field is required");
        }else if(dateto==""){
            alert("Date field is required");
        }
        $(".display").removeAttr('style');
        $(".buttons").removeAttr('style');
        
        var url = '<?php echo base_url();?>index.php/welcome/getmonthstar';
        var html="";
        var pr_amt=$('#parsel_amt').val();
            if($('#prasadam').val() == 1){
            var prasadam_status = 'Yes';
            }
            else if($('#prasadam').val() == 0){
            var prasadam_status = 'No';  
            pr_amt = 0;
            }
            
            var time = $('#time').val();
        var a="1";
        var sel=$('#month option:selected').map(function(_, el) {
            console.log(el);
            var star=$(el).val();
            console.log(star);
            $.ajax({
                type: "POST",
                url: url,
                data: {'from': datefrom,'to': dateto,'star': star,'month':month},
                dataType: "json",
                success: function (data) {
                    $.each(data, function (i, obj)
                    {
                        html +='<tr><td>'+a+'</td>';
                        html +='<td>'+obj.date+'<input type="hidden" name="dates[]" value="'+obj.birth_date+'"></td>';
                        html +='<td>'+obj.name_eng+'</td>';
                        html +='<td>'+prasadam_status+'</td>';
                        html +='<td>'+time+'</td>';
                        html +='<td><i class="fa fa-trash" onclick="return remove_file_row(this)"></i></td></tr>';
                        a++;
                        $("#cdt").val(obj.date);
                    });
                    $('#mytbody').html(html);
                    $(".dateto").show();
                    
                }
            });
        }).get();
        
    }
    function othersub(){

        
        var datefrom=$('#datefrom').val();
        var days = parseInt($('#days').val());
            var week = parseInt($('#weeks').val());
            var month = parseInt($('#months').val());
            var year = parseInt($('#years').val());
        // var dateto=$('#dateto').val();
            var date = Date.parse(datefrom).add({ years: year, months: month, weeks:week, days:days });
            var dateto =  date.toString('yyyy-MM-dd');
        if(datefrom==""){
            alert("Date field is required");
        }else if(dateto==""){
            alert("Date field is required");
        }
        $(".display").removeAttr('style');
        $(".buttons").removeAttr('style');
        $("#cdt").val(dateto);
        var url = '<?php echo base_url();?>index.php/welcome/getother';
        var html="";
        var pr_amt=$('#parsel_amt').val();
            if($('#prasadam').val() == 1){
            var prasadam_status = 'Yes';
            }
            else if($('#prasadam').val() == 0){
            var prasadam_status = 'No';  
            pr_amt = 0;
            }
            
            var time = $('#time').val();
        var a="1";
        var sel=$('#other_id option:selected').map(function(_, el) {
            console.log(el);
            var other=$(el).val();
            console.log(other);
            $.ajax({
                type: "POST",
                url: url,
                data: {'from': datefrom,'to': dateto,'other': other},
                dataType: "json",
                success: function (data) {
                    $.each(data, function (i, obj)
                    {
                        html +='<tr><td>'+a+'</td>';
                        html +='<td>'+obj.date+'<input type="hidden" name="dates[]" value="'+obj.birth_date+'"></td>';
                        html +='<td>'+obj.name_eng+'</td>';
                        html +='<td>'+prasadam_status+'</td>';
                        html +='<td>'+time+'</td>';
                        html +='<td><i class="fa fa-trash" onclick="return remove_file_row(this)"></i></td></tr>';
                        a++;
                    });
                    $('#mytbody').html(html);
                    
                }
            });
        }).get();
        
    } 
    function nameadd()
        {
        var name=$('#name').val();
      
        $('#namep').val(name)
            
            }
            function test()
        {
        document. getElementById('100'). style. backgroundColor = 'Red';
    
    }
</script>
</body>
</html>