<!-- banner -->
<style>
    td{
        padding:10px 5px !important;
    }

	.select2-selection__rendered {
	    line-height: 31px !important;
	}
	.select2-container .select2-selection--single {
	    height: 40px !important;
        border-radius: 0px;
	}
	.select2-selection__arrow {
	    height: 34px !important;
	}	
</style>
<!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" /> -->
        <section class="inner_page uk-clearfix">
            <div class="uk_container ">
            <form action="<?php echo base_url(); ?>index.php/welcome/cart" method="post">
                <div class="uk-card uk-card-default uk-card-body uk-padding-remove-top">
                    <div class="title">
                    <h3>Pooja Booking </h3>
                    <span style="color:red;"><i>(PRM->Prasadam <small> For sending prasadam please tick the checkbox.. </small>)</i></span>
                    <div class=" form_group ">
                      <a href="<?php echo base_url(); ?>index.php">    <button type="button" class="btn_com" style="float: right;margin-top: -40px;"> <i class="fa fa-angle-left"></i> &nbsp;&nbsp; Back to Home</button> </a>
                    </div>
                    </div>
                        <div class="uk-width-expand@m">
                            <div class="uk-overflow-auto">
                                <table class="uk-table uk-table-hover uk-table-divider" id="dataTable2">
                                    <thead>
                                        <tr>
                                            <th> </th>
                                            <th style="width:2cm;">DEITY</th>
                                            <th style="width:2cm;">POOJA </th>
                                            <th style="width:3.5cm;">NAME</th>
                                            <th style="width:3.5cm;">STAR</th>
                                            <th style="width:3cm;">DATE</th>
                                            <th>QTY</th>
                                            <th>AMT</th>
                                            <th>TIME</th>
                                            <th title="Prasadam">PRM</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        if (isset($pooja_ids)){
                                        $total = 0;
                                        $row_count = 100;
                                        foreach ($pooja_ids as $val){
                                            $diety=$this->db->query("SELECT diety_pooja.*,diety.name as diety_nm,pooja.name as pooja_nm FROM `diety_pooja` JOIN diety ON diety.id=diety_pooja.temple_id JOIN pooja ON pooja.id=diety_pooja.pooja_id WHERE diety_pooja.id='$val'")->row_array();
                                            $total = $total+$diety['rate'];
                                            ?>
                                        <tr>
                                            <td> <button type="button" class="uk-button uk-button-default uk-button-small uk-first-column" onclick="return remove_file_row(this)">   <i class="fa fa-trash"></i> </button> </td>
                                            <td style="width:2cm;"><strong style="color: #ec2531;"> <?= $diety['diety_nm']?><input type="hidden" name="diety_id[]" value="<?= $diety['temple_id']?>"> </strong>  </td>
                                            <td style="width:2cm;">
                                                <div> <?= $diety['pooja_nm']?><input type="hidden" name="pooja_id[]" value="<?= $diety['pooja_id']?>"></div>
                                            </td>
                                            <td style="width:3.5cm;">
                                                <input style="width: 3.5cm;" class="uk-input uk-width-1-2" id="name_<?= $row_count;?>" type="text" name="name[]" placeholder="Name" required> </td>
                                            </td>
                                            <td style="width:3.5cm;"><select name="star[]" class="uk-input uk-width-1-2 js-example-basic-single" id="star_<?= $row_count;?>" <?php if($row_count==100){?>onchange="conformation()"<?php }?> required style="width: 3.5cm;">
                                                    <option value="">Select Star </option>
                                                <?php foreach($birth_star as $val){ ?>  
                                                    <option value="<?= $val['id']; ?>"><?php echo $val['name_eng']." - ".$val['name_mal']; ?></option>
                                                <?php } ?>
                                                </select>
                                            </td>
                                          <?php
                                          $site_time = $this->general_model->gettime();
                                          $current_time = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
                                          $current_hour = $current_time->format('H');

                                                if ($current_hour >= $site_time) { 
                                                    $min_date = date('Y-m-d', strtotime("+2 day")); 
                                            } else {
                                                    $min_date = date('Y-m-d', strtotime("+1 day"));
                                                }
                                            ?>

                                            <td style="width:3cm;">
                                                <input style="width: 3cm;" class="uk-input uk-width-1-2" name="date[]" type="date" min="<?= $min_date ?>" value="<?= $min_date ?>">
                                            </td>

                                            <!-- <td style="width:3cm;"> <input style="width: 3cm;" class="uk-input uk-width-1-2" name="date[]" type="date" min="<?= date('Y-m-d', strtotime("+1 day"));?>" value="<?= date('Y-m-d', strtotime("+1 day"));?>"> </td> -->
                                            <td><input style="width: 100%;" class="uk-input uk-width-1-2" type="number" min="1" id="qlt_<?= $row_count;?>" name="qlt[]" onchange="change_rate('<?= $row_count;?>')" onkeyup="change_rate('<?= $row_count;?>')" value="1" placeholder="Qty"> 
                                            <input style="width: 100%;" class="uk-input uk-width-1-2" type="hidden" id="rate_<?= $row_count;?>" name="rate[]" value="<?= $diety['rate']?>" placeholder="Rate" readonly> </td>
                                            <td><input style="width: 100%;" class="uk-input uk-width-1-2" type="text" id="amt_<?= $row_count;?>" name="amt[]" onkeyup="totalcalc()" value="<?= $diety['rate']?>" placeholder="Amount" readonly> </td>
                                            <td style="width:1cm;"><select name="time[]" id="time_100"  class="uk-input uk-width-1-2" required style="width: 1cm;">
                                                    <option value="M" selected="selected">M</option>
                                                    <option value="N">N</option>
                                                    <option value="E">E</option>
                                                </select></td>
                                                <td class="uk-text-center"><input class="uk-checkbox" value="0"  title="Prasadam" id="prs_<?= $row_count;?>" onclick="checkprs('<?= $row_count;?>')" type="checkbox">
                                                <input type="hidden" name="prs[]" value="0" id="prs1_<?= $row_count;?>"></td>
                                        </tr>
                                        <?php 
                                        $row_count++;
                                        }}?>
                                    </tbody>
                                </table>


                               


                            </div> 
                            <div>
                            <!-- <a href="<?php echo base_url(); ?>index.php/welcome/single_booking" class="uk-margin-medium-top  btn_com"> <i class="fa fa-plus"></i> Add More</a> -->
                        </div>
                    
                        <div class="uk-width-expand@m">

                           <div>
                            <h3 style="font-weight: bold;text-align:right;margin: 5px;"> <small> Total Amount :</small> <strong> ₹ </strong><strong id="total"><?php if (isset($pooja_ids)){echo $total;?></strong><input type="hidden" name="total" id="totaltop" value="<?= $total?>"><?php }?> </h3>

<div id="divToShow" style="display:none;">
                                <p style="font-weight: bold;"> Prasadam Shipping <small style="color:red;"><i>(The rate will get changed when you choose the below option)</i></small></p>
                                <div class="uk-form-controls">
                                    <div class="wrap_select_dropdown">
                                    
                                    <select class="drop_category uk-input  drop_select hide " name="prasadam" style="width: 40%;">
                                        <option value="post">Postel</option>
                                        <option value="courier">Courier</option>
                                    </select>
                                    </div>
                               
                                </div>
</div>

                           </div>
                           <div class=" form_group " style="margin-top: 80px; ">

                        <a href="">   <button type="submit" class="btn_com" style="width: 100%;">  Proceed to Payment &nbsp;  <i class="fa fa-angle-right"></i> </button></a> 
                             
                        </div>

                        </div>
                     
                      
                    </div>



                    


                </div>
            </form>
            </div>

 


        </section>
     

        <footer>
            <div class="uk_container">
                        <a href=""> 2021 All rights reserved.</a>

            </div>
        </footer>



       
   


</body>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>

	$(document).ready(function() {
        $('#name_100').focus();
	    $('.js-example-basic-single').select2();
	});

    $(document).on('select2:open', () => {
    	document.querySelector('.select2-search__field').focus();
  	});

    function conformation(){
        var rowCount = $('#dataTable2 tr').length;
        if(rowCount>2){
            if (confirm('Do You Want to Use Same Name And Star..?')) {
                var name=$('#name_100').val();
                var star=$('#star_100').val();
                for (i = 101; i < 1000; i++) {
                    $('#name_'+i).val(name);
                    $('#star_'+i).val(star).change();
                }
            }
        }
    }
    function checkprs(e){
        if($("#prs_"+e).prop('checked') == true){
            $("#prs1_"+e).val("1");
        }else{
            $("#prs1_"+e).val("0");
        }
    }
    function mainNav() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
        x.className += " responsive";
        } else {
        x.className = "topnav";
        }
    }
    
    function remove_file_row(obj){
        $(obj).closest('tr').remove();
        totalcalc()
        return false;
    }
    
    function totalcalc(){
        var i;
        var table = document.getElementById('dataTable2');
        var rowCount = table.rows.length;
        var tot=0;
        // alert(rowCount);
        for (i = 100; i < 1000; i++) {
            if (!isNaN(parseInt($('#amt_'+i).val()))){
                tot += parseInt($('#amt_'+i).val());
            }
        }
        $('#total').html(tot);
        $('#totaltop').val(tot);
    }
    
    function change_rate(e){
        var qlt=$('#qlt_'+e).val();
        var rate = $('#rate_'+e).val();
        var amt=qlt*rate;
        $('#amt_'+e).val(amt);
        totalcalc();
    }


    function checkprs(count) {
    var checkbox = document.getElementById("prs_"+count);
    var divToShow = document.getElementById("divToShow");
    if (checkbox.checked) {
        divToShow.style.display = "block";
    } else {
        divToShow.style.display = "none";
    }
}
</script> 
</html>