<!DOCTYPE html>
<html lang="en" dir="ltr" draggable="false">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> കോവൂർ  ശ്രീ  വിഷ്ണു  ക്ഷേത്രം </title>
    
     <!-- fav icons -->
    <link rel="icon" type="image/x-icon" href="<?php echo base_url(); ?>/assets/online_booking/images/fav_icon.png">

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- css -->
    <link href="<?php echo base_url(); ?>/assets/online_booking/plugin/select2/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/css/uikit.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/fonts/font-awesome-4.6.3/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/css/components/form-advanced.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/scss/site_style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/scss/responsive.css">




     <!-- js -->

     
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/jquery-3.6.0.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/uikit.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/uikit-icons.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/plugin/select2/js/select2.min.js"></script> 
     <script>
            $(document).ready(function() {
                     $('.drop_category').select2();
                      theme: "classic"
                  });
     
     </script> 
     

</head>
<body>
        <!-- header -->
        <header>
            <div class="uk_container " > 
                 
                    <div class="header_nav">
                        <div class="col brand">
                            <a href="<?php echo base_url(); ?>">    <img src="<?php echo base_url(); ?>/assets/online_booking/images/logo.png" title="" alt=""></a>
                        </div>
                        <div class="col header_right header_dp_area">
                           <!-- <div>
                               <a href="" class="btn_com">Complaints</a></div> -->
                            <div>

                                <div class="uk-inline dp_wrap">

                                    <div class="info">
                                        <div class="info_img"> 
                                            <img style="width: 30px;" src="http://kovoorvishnutemple.com//assets/new_site/images/icons/icons5.png" title="" alt="" width="42px" height="52px"> </div>
                                        <div class="contact_info">
                                          <div><i class="fa fa-phone-square"></i>&nbsp;&nbsp;0495 – 2359561 , 99999999999 </div>
                                          <div><i class="fa fa-envelope"></i>&nbsp;&nbsp;kovoorvishnutemple@gmail.com</div>
                                        </div>
                                      </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </header>      
        
        <!--end header -->
        <!-- banner -->
        <section class="inner_page uk-clearfix">
            <div class="uk_container ">
                <div class="uk-card uk-card-default uk-card-body" style="margin-top: -30px;">
                    <div uk-grid>
                        <div class="uk-width-expand@m" style="max-width: 35%;">
                            <h3>Login</h3>
                            <div class="form_wraper" uk-grid>
                            <div class="alert alert-danger" style="color: red;">
                                                            <?php echo $this->session->flashdata('message1'); ?>
                                                        </div>
                            <form action="<?php echo base_url(); ?>index.php/welcome/login" method="post">
                                <div class="uk-width-1-1@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Username</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="username" type="text" placeholder="Username">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-1@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Password</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="password" type="text" placeholder="Password ">
                                        </div>
                                    </div>
                                    <p> <input class="uk-checkbox" type="checkbox"> Remember Password </p>
                                   </div>
                                   <div class="uk-width-1-1@m uk-margin-small-top uk-text-right">
                                    <div class=" form_group ">
                                       <a href="">  <button type="submit" class="btn_com">Login</button></a>
                                    </div>
                                   </div>

                                </form>
                             </div>
                             <div class = "vertical">
                                <h4 style="padding-top: 135px;margin-left: -17px;">OR</h4>
                             </div>

                        </div>

                        <style>
        .vertical {
            border-left: 1px solid black;
            height: 300px;
            margin-left: 300px;
            margin-top: -299px;
        }
    </style>
                  


            <div class="uk_container " style="max-width: 65%;">
                <div class="uk-card uk-card-default uk-card-body" style="padding-top: 0px;">
                <form action="<?php echo base_url(); ?>index.php/welcome/signup" method="post">
                    <div uk-grid>
                        <div class="uk-width-expand@m">
                            <h3>Book as a Guest</h3>
                            <div class="form_wraper" uk-grid>
                                                        <div class="alert alert-danger" style="color: red;">
                                                            <?php echo $this->session->flashdata('message'); ?>
                                                        </div>

                                <div class="uk-width-1-1@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Name</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="name" type="text" placeholder="Name">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Phone</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-ph" name="phone" type="number"  pattern="[0-9]{10}"  maxlength="10" placeholder=" " required>
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Email <small>(Username)</small></label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="email" type="email" placeholder=" " required>  
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">House Name</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="house" type="text" placeholder="">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Post Office</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="post" type="text" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Place</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-text" name="street" type="text" placeholder=" ">  
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">  
                                        <label class="uk-form-label" for="form-stacked-text">State</label>
                                        <div class="uk-form-controls">
                                            <div class="wrap_select_dropdown">
                                            <select class="drop_category uk-input  drop_select hide " name="state" style="width: 100%;">
                                                <option value="Kerala">Kerala</option>
                                                <option value="Tamilnadu">Tamilnadu</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Pincode</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input" id="form-stacked-pin" name="pincode" type="number" maxlength="6" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Password<small>(Optional)</small></label>
                                        <div class="uk-form-controls">
                                                <!-- <input class="uk-input" id="form-stacked-text" name="password" type="password" placeholder=" "> -->
                                                <input class="uk-input" id="form-stacked-pass" name="password" type="password" placeholder=" ">
                                                <input type="checkbox" id="show_password" onclick="showPassword()"> Show Password


                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-1@m uk-margin-small-top uk-text-right">
                                    <div class=" form_group ">
                                        <input type="submit" class="btn_com"style="background: #0d8c1b;"name="register" value="Register as a User">
                                        <input type="submit" class="btn_com" name="guest" value="Proceed as a Guest">
                                    <script>
                                    function showPassword() {
                                        var passwordInput = document.getElementById("form-stacked-pass");
                                        var checkbox = document.getElementById("show_password");

                                        if (checkbox.checked) {
                                            passwordInput.setAttribute("type", "text");
                                        } else {
                                            passwordInput.setAttribute("type", "password");
                                        }
                                    }
                                    </script>                                    

                                    </div>
                                   </div>

                             </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>


<script>
    alert('<?php echo $msg; ?>');
</script>
  
                        <!-- <div class="uk-width-1-3@m">
                            <div class="rigt_sign">
                                    <div class="box_go_log">
                                          <h3 style="    font-size: 18px; font-weight: bold;">  Already Registerd ?</h3>

                                            <a href="<?php echo base_url(); ?>index.php/welcome/login" class="btn_com" >Go to Login</a>
                                    </div>
                            </div>
                        </div> -->
        

                      
                    </div>
                </div>

            </div>
   

  <!-- This is the modal -->
  <div id="my_success" uk-modal="bg-close: false;">
    <div class="uk-modal-dialog uk-modal-body wrap_pop">
            <div class="popup_text">
                <img class="success_animation" src="<?php echo base_url(); ?>/assets/online_booking/images/tick-success.svg" alt="">
            <h2>Thank you for uploading the slip.</h2>
            <p> Our team will verify the details and will get back to you on this</p>
       
            <div>
            <button class="btn_com uk-modal-close" style="width: 150px;">OK</button>
             
        </div>
        </div>
      
    </div>
</div>


        </section>

        <footer>
            <div class="uk_container">
                        <a href="">  2021 All rights reserved.</a>

            </div>
        </footer>

</body>
<script>
    document.getElementById("form-stacked-pin").addEventListener("input", function (event) {
  if (this.value.length > 6) {
    this.value = this.value.slice(0, 6);
  }
});

document.getElementById("form-stacked-ph").addEventListener("input", function (event) {
  if (this.value.length > 10) {
    this.value = this.value.slice(0, 10);
  }
});
    </script>


</html>