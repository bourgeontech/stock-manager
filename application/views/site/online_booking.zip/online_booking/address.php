        <!-- banner -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <section class="inner_page uk-clearfix">
            <div class="uk_container ">

<?php
$temple_list=$this->general_model->gettemples();
$getcontact=$this->site_model->getcontact();
$site_settings=$this->site_model->settings();
$bgimage=$site_settings['bgimage'];
if(isset($this->loggedIn)){
    $name=$this->loggedIn['name'];
}
     ?>              
                  


                <div class="uk-card uk-card-default uk-card-body uk-padding-remove-top">
                    <div class="title">
                    </div>
                    <div uk-grid>
                        <div class="uk-width-expand@m" style="max-width: 50%;">
                            <!-- <div class="user_profile">
                                <div class="user_dp">
                                    <img src="<?php echo base_url(); ?>/assets/online_booking/images/temple.jpg" alt="">
                                </div>
                                <div class="contact_info">
                                    <h3><?php print $site_settings['templename_eng']; ?></h3>
                                    <ul class="contact">
                                        <li>  <div class="icon"> <i class="fa fa-phone"></i></div> 
                                            <div><?php print $temple_list[0]['phone']; ?></div></li>
                                        <li> <div class="icon">  <i class="fa fa-envelope"></i></div>  <?php print $temple_list[0]['email']; ?></li>
                                        <li> <div class="icon">  <i class="fa fa-map-marker"></i></div>  <?php print $temple_list[0]['address']; ?>. <?php print $temple_list[0]['pincode']; ?> ,Kerala, India</li>
                                    </ul>
                                <p></p>
                                </div>
                            </div> -->
                            <div class="uk-width-1-1@m">

<div>

 <div class="title">
     <h3>  Billing Summary</h3>
     </div>

     <style>
         .summery_table{
             box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
             padding: 30px 30px 10px 30px;
             border-bottom: 2px solid #fbfbfb;
         }
         .summery_table td {
             font-weight: bold;
             font-size: 16px;
         }
     </style>
 <div class="summery_table">
 <table class="uk-table uk-table-divider  " style="border: none;">
     
     <tbody>
         <tr>
             <td> Total Amount</td>
             <td>:</td>
             <td class="uk-text-right">₹  <?php echo $total;?></td>
        
         </tr>
        <?php
            $query = $this->db->query("SELECT postel_charge FROM temple WHERE id='1'");
            $row = $query->row(); 
            $tot_pramd = $row->postel_charge; 
        ?>
         <tr>
             <td> Prasadam Sending</td>
             <td>:</td>
             <td class="uk-text-right">₹  <?php echo $tot_pramd;?></td>
        
         </tr>
         <!-- <?php
            $query2 = $this->db->query("SELECT payment_charge FROM temple WHERE id='1'");
            $row = $query2->row(); 
            $addcha = $row->payment_charge; 
        ?> -->
         <tr>
             <td> Additional Charges </td>
             <td>:</td>
             <td class="uk-text-right">₹  0</td>
        
         </tr>
         <tr>
             <td>  Total to be Paid </td>
             <td>:</td>
             <td class="uk-text-right">₹  <?php echo $total+$tot_pramd;?></td>
        
         </tr>
         
     </tbody>
 </table>
</div>
</div>
</div>




                            <?php if($tot_pramd!=0){?>
                                <!-- <form>
                            <div class="form_wraper" uk-grid>
                                   <div class="uk-width-1-2@m uk-margin-medium-top uk-margin-small-bottom"> 
                                        <h3 style="font-weight: bold;">Prasadam Sending Address</h3>
                                    </div>
                                    <div class="uk-width-1-2@m uk-margin-medium-top uk-margin-small-bottom"> 
                                        <h4 style="text-align:right">My Existing Address <input type="checkbox" id="ex_address" value="1"></h4>
                                    </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Name</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="name" id="name" placeholder="Name">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Phone</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="phone" id="phone" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Email</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="email" id="email" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">House Name</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="house" id="house" placeholder="">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Post Office</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text"  name="post" id="post" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Place</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="place" id="place" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">State</label>
                                        <div class="uk-form-controls">
                                            <div class="wrap_select_dropdown">
                                            <select class="drop_category uk-input  drop_select hide " name="state" id="state" style="width: 100%;">
                                                <option value="KERALA">KERALA</option>
                                                <option value="TAMILNADU">TAMILNADU</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                    <div class=" form_group">
                                        <label class="uk-form-label" for="form-stacked-text">Pincode</label>
                                        <div class="uk-form-controls">
                                                <input class="uk-input"  type="text" name="pincode" id="pincode" placeholder=" ">
                                        </div>
                                    </div>
                                   </div>
                                   <div class="uk-width-1-2@m uk-margin-small-top">
                                   </div>
                                   <div class="uk-width-1-1@m uk-margin-small-top uk-text-right">
                                    <div class=" form_group ">
                                        <button type="button" class="btn_com">Save</button>
                                    </div>
                                   </div>
                                </div>
                                </form> -->
                                <?php }?>
                            <div>
                        </div>
                    
                    </div>
                    <div>
                    <div class="title">
                        <?php
                        if ($user_dtl['user_type'] == 1) {
                            echo "Welcome, registered user!";
                        } else if ($user_dtl['user_type'] == 0) {
                            echo "Welcome, guest!";
                        }
                        ?>                        
                    <h3> Billing Address </h3>
                    <button id="change-address-button" class="btn btn-light"  type="button">Change in Address ?</button>


                        </div>
                    <p style="font-size: 16px;     font-weight: bold;">
                       <?= $user_dtl['name']?>,<br>
                       <span id="house-update"><?= $user_dtl['house']?></span> <br>  <span id="street-update"><?= $user_dtl['street']?>,</span><br>
                       <span id="post-update"><?= $user_dtl['post']?></span> (PO) -  <span id="pincode-update"><?= $user_dtl['pincode']?> ,</span> <br>
                       <span id="state-update"> <?= $user_dtl['state']?>,</span> India
                    </p>
                    <div class=" form_group " style="margin-top: 30px; ">
                    <button type="submit" class="btn_com" id="make_payment"  onclick="razorpaySubmit(this);"
                    style=" width: 100%; font-weight: bold;">  Make Payment &nbsp;  <i class="fa fa-angle-right"></i> </button>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
        </section>



        <!-- Modal container -->
<div id="address-modal" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <form id="address-form">
                    <div class="uk-width-1-2@m uk-margin-small-top">
                        <div class=" form_group">
                            <label class="uk-form-label" for="form-stacked-text">House Name </label>
                            <div class="uk-form-controls">
                                    <input class="uk-input" id="house" name="house" type="text" placeholder=" <?= $user_dtl['house']?>"required>
                            </div>
                        </div>
                        </div>
                        <div class="uk-width-1-2@m uk-margin-small-top">
                        <div class=" form_group">
                            <label class="uk-form-label" for="form-stacked-text">Post Office</label>
                            <div class="uk-form-controls">
                                    <input class="uk-input" id="post" name="post" type="text" placeholder=" <?= $user_dtl['post']?> "required>
                            </div>
                        </div>
                        </div>
                        <div class="uk-width-1-2@m uk-margin-small-top">
                        <div class=" form_group">
                            <label class="uk-form-label" for="form-stacked-text">Place</label>
                            <div class="uk-form-controls">
                                    <input class="uk-input" id="street" name="street" type="text" placeholder=" <?= $user_dtl['street']?>"required>  
                            </div>
                        </div>
                        </div>
                        <div class="uk-width-1-2@m uk-margin-small-top">
                        <div class=" form_group">  
                            <label class="uk-form-label" for="form-stacked-text">State</label>
                            <div class="uk-form-controls">
                                <div class="wrap_select_dropdown">
                                <select class="drop_category uk-input  drop_select hide " id="state" name="state" placeholder="<?= $user_dtl['state']?>" style="width: 100%;"required>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Tamilnadu">Tamilnadu</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        </div>
                        <div class="uk-width-1-2@m uk-margin-small-top">
                        <div class=" form_group">
                            <label class="uk-form-label" for="form-stacked-text">Pincode</label>
                            <div class="uk-form-controls">
                                    <input class="uk-input" id="pincode" name="pincode" type="number" maxlength="6" placeholder="<?= $user_dtl['pincode']?> "required>
                            </div>
                        </div>
                        </div>
                        <input type="hidden" id="url" value="<?php echo base_url('index.php/welcome/update_address'); ?>" />
                    <button id="submit-address-button" class="btn_com" type="submit" style="padding: 10px;margin-top: 15px;">Update Address</button>
                    </form>
  </div>
</div>
     <style> 
     /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
}
</style>

        <footer>
            <div class="uk_container">
                        <a href=""> 2021 All rights reserved.</a>

            </div>
        </footer>



        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var options = {
            key:            "rzp_test_rmTB5HHv6nrDYZ",
            amount:         "<?php echo ($total+$tot_pramd)*100; ?>",
            name:           "<?php print $site_settings['templename_eng']; ?>",
            description:    "Pooja Booking",
            netbanking:     true,
            currency:       "INR", // INR
            prefill: {
                name: "<?php echo $user_dtl['name']; ?>",
                email   : "<?php echo $user_dtl['email']; ?>",
                contact : "<?php echo $user_dtl['mobile']; ?>"
            },
            notes: {
                "address": "<?php echo $user_dtl['district']." , ".$user_dtl['state']; ?>"
            },
            handler: function (response) {
                window.location = "<?php echo base_url(); ?>index.php/welcome/do_payment/"+response.razorpay_payment_id;
            },
            "modal": {
                "ondismiss": function(){
                    location.reload()
                }
            }
        };

        var razorpay_pay_btn, instance;
        function razorpaySubmit(el) {
            if(typeof Razorpay == 'undefined') {
                setTimeout(razorpaySubmit, 200);
                if(!razorpay_pay_btn && el) {
                    razorpay_pay_btn    = el;
                    el.disabled         = true;
                    el.value            = 'Please wait...';  
                }
            } else {
                if(!instance) {
                    instance = new Razorpay(options);
                    if(razorpay_pay_btn) {
                    razorpay_pay_btn.disabled   = false;
                    razorpay_pay_btn.value      = "Pay Now";
                    }
                }
                instance.open();
            }
        }  

        $( "#ex_address" ).click(function() {
            if($("#ex_address").prop('checked') == true){
                var qlt="1";                                    
                var url = "<?php echo base_url(); ?>index.php/welcome/getuserdtls";
                $.ajax({
                    type: "GET",
                    url: url,
                    data: {'qlt': qlt},
                    dataType: "json",
                    success: function (data) {
                        // console.log(data);
                        $("#name").val(data.name);
                        $("#phone").val(data.mobile);
                        $("#email").val(data.email);
                        $("#house").val(data.house);
                        $("#post").val(data.post);
                        $("#place").val(data.district);
                        $("#state").val(data.state).select();
                        $("#pincode").val(data.pincode);
                    }
                });
            }else{
                $("#name").val("");
                $("#phone").val("");
                $("#email").val("");
                $("#house").val("");
                $("#post").val("");
                $("#place").val("");
                $("#state").val("");
                $("#pincode").val("");
            }
        });



const button = document.getElementById("change-address-button");
const modal = document.getElementById("address-modal");
const close = document.getElementsByClassName("close")[0];
const submitAddress = document.getElementById("submit-address-button");

button.addEventListener("click", function() {
  modal.style.display = "block";
});

close.addEventListener("click", function() {
  modal.style.display = "none";
});

window.addEventListener("click", function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
});

submitAddress.addEventListener("click", updateAddress);

function updateAddress(e) {
  e.preventDefault(); 
  const house = document.getElementById("house").value;
  const post = document.getElementById("post").value;
  const street = document.getElementById("street").value;
  const state = document.getElementById("state").value;
  const pincode = document.getElementById("pincode").value;
  const url = document.getElementById("url").value;

  if (!house || !street || !post || !state || !pincode) {
    alert("Please fill out all the fields");
    return;
  }

      
     $.ajax({
         type: "POST",
         url: url, 
         data:{
            house: house,
            street: street,
            post: post,
            state: state,
            pincode: pincode,
        },
        success:function(data){
           if(data == 1){
            modal.style.display = "none";
            console.log(house);
            $("#house-update").val(house);
            $("#street-update").val(house);
            $("#post-update").val(house);
            $("#state-update").val(house);
            $("#pincode-update").val(house);
            location.reload();
           }
        }

    });

    
}


    </script>  
</body>
</html>