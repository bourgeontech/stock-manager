<!DOCTYPE html>
<html lang="en" dir="ltr" draggable="false">
<?php 
$temple_list=$this->general_model->gettemples();
$getcontact=$this->site_model->getcontact();
$site_settings=$this->site_model->settings();
$bgimage=$site_settings['bgimage'];
if(isset($this->loggedIn)){
    $name=$this->loggedIn['name'];
}
$title=$this->session->title;
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php print_r($temple_list[0]['name']);?> </title>
    
    <!-- fav icons -->
    <link rel="icon" href="<?php echo base_url(); ?>/assets/new_site/images/fav_icon.png" type="images/png" sizes="35x35" />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- css -->
    <link href="<?php echo base_url(); ?>/assets/online_booking/plugin/select2/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/css/uikit.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/fonts/font-awesome-4.6.3/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/css/components/form-advanced.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/scss/site_style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/online_booking/scss/responsive.css">




     <!-- js -->

     
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/jquery-3.6.0.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/uikit.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/js/uikit-icons.min.js"></script>
     <script src="<?php echo base_url(); ?>/assets/online_booking/plugin/select2/js/select2.min.js"></script> 
     <script>
            $(document).ready(function() {
                     $('.drop_category').select2();
                      theme: "classic"
                  });
     
     </script> 
      <script>
        function mainNav() {
          var x = document.getElementById("myTopnav");
          if (x.className === "topnav") {
            x.className += " responsive";
          } else {
            x.className = "topnav";
          }
        }
        </script> 

</head>
<body>
        <!-- header -->
        <header>
            <div class="uk_container "> 
                 
                    <div class="header_nav">
                        <div class="col brand">
                            <a style="font-size:18px;font-weight:bold;text-transform:uppercase;"><?php print $site_settings['templename_mal']; ?><br><?php print $site_settings['templename_eng']; ?></a>
                        </div>
                        <div class="col header_right header_dp_area">
                           <!-- <div>
                               <a href="" class="btn_com">Complaints</a></div> -->
                               <button class="btn_com" id="language-switch"><?php echo ($this->session->userdata('language') == 'english') ? ' Malayalam' : ' English'; ?></button>

                               <script>
                                $('#language-switch').click(function() {
                                    var newLanguage = '<?php echo ($this->session->userdata('language') == 'english') ? 'malayalam' : 'english'; ?>';
                                    $.ajax({
                                        url: '<?php echo base_url(); ?>index.php/welcome/set_language',
                                        type: 'POST',
                                        data: {language: newLanguage},
                                        success: function(response) {
                                            window.location.reload();
                                        }
                                    });
                                });
                            </script>
                            <div>

                                <div class="uk-inline dp_wrap">
                                <?php if(isset($name)){?>
                                    <div class="dp_name">Hi, <?php if(isset($name)){ echo $name;}?></div>
                                    <div class="dp_profile">   </div>
                                    
                                     
                                    <div uk-dropdown>
                                        <ul class="uk-nav uk-dropdown-nav">
                                            <?php if(isset($name)){?>
                                            <li><a href="<?php echo base_url(); ?>index.php/welcome/logout"> <i class="fa fa-power-off" aria-hidden="true"></i> &nbsp; Logout</a></li>
                                            <?php }else{?>
                                            <li><a href="<?php echo base_url(); ?>index.php/welcome/login"> <i class="fa fa-power-off" aria-hidden="true"></i> &nbsp; Login</a></li>
                                            <?php }?>
                                        </ul>
                                    </div>
                                <?php }else{?>
                                    <a href="<?php echo base_url(); ?>index.php/welcome/login"><div class="btn_com"> <i class="fa fa-power-off" aria-hidden="true"></i> &nbsp; Login</div></a>
                                <?php }?>
                                </div>
                            </div>
               
                            
                        </div>
                    </div>

            </div>

        </header>
        <!--end header -->
        <section>
           <div class="main_nav">
            <div class="uk_container">
                <div class="topnav" id="myTopnav">

                    <!-- <a href="<?php echo base_url(); ?>index.php">  <i class="fa fa-home"></i> Home</a>
                    <a href="<?php echo base_url(); ?>index.php/welcome/single_booking" <?php if($title=="single_booking"){ ?> class="active" <?php }?>>  Single Day Booking</a>
                    <a href="<?php echo base_url(); ?>index.php/welcome/multiple_booking" <?php if($title=="multiple_booking"){ ?> class="active" <?php }?>>   Multiple Day Booking</a>
                    <?php if(isset($name)){
                        // if( $this->session->userdata('admin')['user_type'] == 1){ ?>
                           <a href="<?php echo base_url(); ?>index.php/welcome/summary_print" <?php if($title=="summary_print"){ ?> class="active" <?php }?>>   Pooja Summary</a>
                    <?php }  ?> -->



                    <a href="<?php echo base_url(); ?>index.php">  <i class="fa fa-home"></i> <?php echo ($this->session->userdata('language') == 'english') ? 'Home' : 'ഹോം'; ?></a>
                    <a href="<?php echo base_url(); ?>index.php/welcome/single_booking" <?php if($title=="single_booking"){ ?> class="active" <?php }?>> <?php echo ($this->session->userdata('language') == 'english') ? 'Single Day Booking' : 'ഒറ്റ ദിവസ ബുക്കിംഗ്'; ?></a>
                    <a href="<?php echo base_url(); ?>index.php/welcome/multiple_booking" <?php if($title=="multiple_booking"){ ?> class="active" <?php }?>> <?php echo ($this->session->userdata('language') == 'english') ? 'Multiple Day Booking' : 'പല ദിവസ ബുക്കിംഗ്'; ?></a>
                    <?php if(isset($name)){
                        // if( $this->session->userdata('admin')['user_type'] == 1){ ?>
                        <a href="<?php echo base_url(); ?>index.php/welcome/summary_print" <?php if($title=="summary_print"){ ?> class="active" <?php }?>> <?php echo ($this->session->userdata('language') == 'english') ? 'Pooja Summary' : 'പൂജാ സംഗ്രഹം'; ?></a>
                    <?php }  ?>

                    <a href="#" uk-toggle="target: #my-id"> 
                    <?php echo ($this->session->userdata('language') == 'english') ? 'Instructions' : 'നിർദ്ദേശങ്ങൾ'; ?>
                    </a>
                    
                    <a href="javascript:void(0);"  class="icon" onclick="mainNav()">&#9776;</a>
                  </div>

            </div>
           </div>
           <!-- <div id="my-id" uk-modal>
                <div class="uk-modal-dialog uk-modal-body">
                    <h2 class="uk-modal-title">Instructions</h2>
                    <p>  
                        
                    </p>
                <div class="uk-text-right">
                    <button class="uk-modal-close   btn_com" type="button">Okay</button>
                    <button class="   btn_com" type="button"> Submit</button>
                </div>
                </div>
            </div> -->

            <div id="my-id" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <h2 class="uk-modal-title">Instruction</h2>
        <p>  
            <iframe src="<?php echo base_url('uploads/pdf/instruction.pdf'); ?>"
                width="540px"
                height="500px"
                style="border: none;"></iframe>
        </p>
        <div class="uk-text-right">
            <button class="uk-modal-close   btn_com" type="button">Okay</button>
            <!-- <button class="   btn_com" type="button"> Submit</button> -->
        </div>
    </div>
</div>


        </section>
