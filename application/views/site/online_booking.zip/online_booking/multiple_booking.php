<!-- banner -->
        <section class="inner_page uk-clearfix">
            <div class="uk_container ">

                <div class="uk-card uk-card-default uk-card-body uk-padding-remove-top">
                    <div class="title">
                    <h3>Multiple Day Pooja Booking</h3>
                    </div>
                    <div uk-grid>
                        <div class="uk-width-1-1@m">


                        
                            <div class="pooja_div">

                                <div class="left_col">
                                    <h3 class="uk-text-center" style="font-weight: bold; font-size: 16px;"> 
                                        Select Deity 
                                        <br>
                                      <small> (പ്രതിഷ്ഠ  തിരഞ്ഞെടുക്കുക) </small> </h3>

                                <ul class="uk-nav uk-nav-default diety_list" uk-switcher="connect: #component-nav; animation: uk-animation-fade">
                                <?php foreach($temple_diety_list as $val){ ?>
                                    <li><a><?= $val['name']; ?></a></li>
                                <?php }?>
                            </ul>
                        </div>

                        <div class="right_col">
                            <ul id="component-nav" class="uk-switcher">
                             <?php foreach($temple_diety_list as $val){ 
                                $this->db->select('diety_pooja.*,pooja.name as pooja,pooja.name_mal as pooja_mal,pooja.rate as pooja_rt,pooja.code');
                                $this->db->from('diety_pooja');
                                $this->db->join('pooja','pooja.id = diety_pooja.pooja_id');
                                $this->db->where('diety_pooja.temple_id', $val['id']);
                                $this->db->order_by("pooja.name", "asc");
                                $query = $this->db->get()->result_array();
                                ?>
                                    <li>

                                        <div>
                                                <h3 class="deity_name"><?= $val['name']." - ".$val['name_mal']; ?></h3>
                                            <table class="uk-table uk-table-divider uk-table-hover ">



                                                <thead>
                                                    <tr>
                                                       
                                                        <th>Vazhipad List (വഴിപാട് വിവരം )</th>
                                                        <th class="uk-text-right"> Rate(₹)</th>
                                                        <th class="uk-text-center"> </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($query as $pooja){?>
                                                    <tr>
                                                       
                                                        <td> <strong> <?= $pooja['pooja']." - ".$pooja['pooja_mal']?> </strong></td>
                                                        <td class="uk-text-right"> <div class="price"> <strong> ₹ <?= $pooja['pooja_rt']?></strong> </div> </td>
                                                        <td class="uk-text-center"> <a href="<?php echo base_url(); ?>index.php/welcome/schedule_booking/<?= $pooja['id']?>"><button class="uk-button btn_com">Book Now</button> </a></td>
                                                    </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>

                                    
                                    </li>
                                    
                                <?php }?>
                            </ul>

                        </div>
                        </div>


                        </div>
                        <!-- <div class="uk-width-1-1@m">
                            <div class="uk-width-1-1@m uk-margin-small-top uk-text-right uk-grid-margin uk-first-column">

                                <div class=" form_group ">

                                    <button type="button" class="btn_com"> <i class="fa fa-angle-left"></i> &nbsp;&nbsp; Back to Home</button>
                                <a href="cart.html">  <button type="button" class="btn_com">Add To Cart</button></a>  
                                </div>
                               </div>


                        </div>
                       -->
                    </div>



                    


                </div>
            </div>

 


        </section>
     

        <footer>
            <div class="uk_container">
                        <a href=""> 2021 All rights reserved.</a>

            </div>
        </footer>



       
   


</body>
</html>